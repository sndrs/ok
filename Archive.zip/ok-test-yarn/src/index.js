import a from './a'

console.log(a)
